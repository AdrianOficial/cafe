<?php
include('session.php');
if(isset($_SESSION['login_user'])){
$id = $_GET['topicID'];
$ttopicmessage = $_POST['ttopicmessage'];
$time = time();
$username = $_SESSION['login_user'];

$sql = "INSERT INTO comments (ID, Text, Author, FirstPage, Time, LastPost) VALUES ('$id', '$ttopicmessage', '$username', '0', '$time', '$username')";

if (mysqli_query($db, $sql)) {
    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($db);
}
}else{
	echo "You're not logged in";
	echo '<meta http-equiv="refresh" content="1; url=index.php" />';

}