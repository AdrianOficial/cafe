<?php
   // ****** TFMPanel by Adryan //
   // ****** Discord Owner : Adryan#2176 (#2176 tag) //
   
   include("config.php");
   session_start();
   $errors = array();
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,a801_encode($_POST['password'])); 
      
      $sql = "SELECT ID FROM users WHERE username = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      		
      if($count == 1) {
         $_SESSION['login_user'] = $myusername;
         
         echo '<meta http-equiv="refresh" content="0; url=index.php" />';
      }
   }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <body>

		<div id="content">
		<div id="contentWrap">
		<div id="contentBox">

    <div id="contentMain"><div id="contentPage">

        <div class="normalContentBox">
        <form action = "" method = "post">
            <table border="0" cellspacing="0" cellpadding="0" width="380" border="0" align="center">
                <tbody><tr>
                    <td width="80">
                        <div class="formLabel">
                            <span class="text">Name</span>:
                        </div>
                    </td>
                    <td width="300" class="textarea">
                        <input name="username" type="text" class="textarea" id="username">
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="formLabel">
                            <span class="text">Password</span>:
                        </div>
                    </td>
                    <td><input name="password" type="password" class="textarea" id="password"></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <div align="center">
                            <input class="loginButton" name="Login" type="submit" id="Login" value="Login">
                        </div>
                    </td>
                </tr>
                </tbody>
				</table>
        </form>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
