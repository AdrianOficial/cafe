<?php
   // ****** TFMPanel by Adryan //
   // ****** Discord Owner : Adryan#2176 (#2176 tag) //
   
   include('config.php');
   session_start();
   
   function pas($a){
	if (isset($_POST[$a])){
		return trim($_POST[$a]);
		
	}
}
?>