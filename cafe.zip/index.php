<?php
   // ****** TFMPanel by Adryan //
   // ****** Discord Owner : Adryan#2176 (#2176 tag) //
	include('session.php');
   
   $topicSelect = "select * from cafe";
   $topicSelect1 = "SELECT count(*) as total from comments";
   $result = $db->query($topicSelect);
   

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Chat</title>
	<link rel="stylesheet" href="./css/style.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>

</head>
<body>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
li a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>

<ul>
  <li><a href="index.php">Home</a></li>
  <?php if(!isset($_SESSION['login_user'])){ ?>
  <li style="float:right"><a href="login.php">Login</a></li>
  <li style="float:right"><a href="register.php">Register</a></li>
  <?php } else { ?>
  <li style="float:right"><li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><?php echo $_SESSION['login_user'] ?></a>
    <div class="dropdown-content">
      <a href="profile.php">Profile</a>
      <a href="logout.php">Log out</a>
    </div>
  </li>
  </li>
  <?php } ?>
</ul>

	<div class="container">
		<div class="cafe">
			<div class="left">
			<?php if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					$id = $row['id'];
					$result1 = $db->query("SELECT COUNT(*) FROM `comments` WHERE ID = '$id'");
					$result2 = $db->query("SELECT LastPost, dontdelete FROM `comments` WHERE ID = '$id' ORDER BY dontdelete DESC");
					$comment = $result1->fetch_row();
					$lastpost = $result2->fetch_row();
					$result3 = $db->query("SELECT avatar FROM `users` WHERE username = '$lastpost[0]'");
					$avatar = $result3->fetch_row();
					?>
				<a href="topic.php?topicid=<?php echo $row['id'];?>" data-tid="<?php echo $row['id'];?>" class="topic active">
					<img src="<?php echo $avatar[0] ?>" alt="<?php echo $lastpost[0] ?>" title="<?php echo $lastpost[0] ?>">
					<div class="info">
						<div id="postName"><?php echo $row['Title'];?></div>
						<div class="postInfo new"><?php echo $comment[0] ?><span>, <?php echo $lastpost[0] ?></span></div>
					</div>
				</a>
				<?php }
			} ?>
				<a href="newTopic.php" class="button"><?=new_topic?></a>
			</div>
		</div>
	</div>
	
</body>
</html>