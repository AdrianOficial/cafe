<?php
//Langues system by Adrya
define("submit", "Submit");
define("mesaj", "Message");
define("new_topic", "New Topic");