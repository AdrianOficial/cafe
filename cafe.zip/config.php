<?php
   // ****** TFMPanel by Adryan //
   // ****** Discord Owner : Adryan#2176 (#2176 tag) //
   
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', '');
   define('DB_DATABASE', 'panel');
   
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   
   
if ( ISSET($_GET["lang"]) ) {
    $language = $_GET["lang"];
} else {
    $language = "en";
}

include('./langues/en.php');
   
   //Hash Atelier801
   

function a801_encode($password)
{
	return base64_encode(hash("sha256", hash("sha256", urldecode($password)).hex2bin("f71aa6de8f1776a8039d32b8a156b2a93edd439dc5ddce56d3b7a4054a0d08b0"), true));
}

?>