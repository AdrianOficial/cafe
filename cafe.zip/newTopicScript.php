<?php
include('session.php');
if(isset($_SESSION['login_user'])){
$titleTopic = $_POST['ttopic'];
$ttopicmessage = $_POST['ttopicmessage'];
$time = time();
$username = $_SESSION['login_user'];

if($ttopicmessage == "<script>") {
	str_replace("<script>", "I'm sucking dick boys.Contact me", $ttopicmessage);
}

$sql = "INSERT INTO cafe (Title, Author, Message, Time) VALUES ('$titleTopic', '$username', '$ttopicmessage', '$time')";

if (mysqli_query($db, $sql)) {
    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($db);
}
}else{
	echo "You're not logged in";
	echo '<meta http-equiv="refresh" content="1; url=index.php" />';
}
